﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Telhai.CS.CsharpCourse._05_WpfLinq
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
